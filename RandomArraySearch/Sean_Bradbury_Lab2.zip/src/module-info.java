/**
 * 
 */
/**
 * @author User
 *
 */
module Lab2 {
	requires org.junit.jupiter.api;
	requires org.opentest4j;
}